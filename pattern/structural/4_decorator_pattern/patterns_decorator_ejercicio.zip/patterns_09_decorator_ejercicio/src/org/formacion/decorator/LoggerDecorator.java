package org.formacion.decorator;

import java.util.List;

public class LoggerDecorator implements BaseDatos {

	@Override
	public void inserta(String registro) {
		// implementar
	}

	@Override
	public List<String> registros() {
		// implementar
		return null;
	}

	

}
